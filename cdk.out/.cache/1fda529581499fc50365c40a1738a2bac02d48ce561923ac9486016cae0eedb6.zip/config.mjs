// Environment variables
export const LOG_LEVEL = process.env.LOG_LEVEL || 'info';

